package com.gsplprojects.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.AnimationUtils;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    public static String logincheck;

   public static SharedPreferences sp;
   public  static SharedPreferences.Editor editor;
    TextView welcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        welcome = (TextView)findViewById(R.id.tview);
        welcome.startAnimation(AnimationUtils.makeInAnimation(MainActivity.this,true));

        // Initializing the shared preference
        sp = getSharedPreferences("ABC", 0);
        editor = sp.edit();

        // check here if user is login or not
        logincheck = sp.getString("logincheck", null);

        if (getIntent().getBooleanExtra("EXIT", false)) {
            finish();
            return;
        }

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {


                if (logincheck != null && !logincheck.toString().trim().equals("")) {

                    Intent send = new Intent(getApplicationContext(), Display.class);
                    startActivity(send);
                }

                else {

                    Intent send = new Intent(getApplicationContext(),Login.class);
                    startActivity(send);

                }
            }

        }, 4000);

    }

}
