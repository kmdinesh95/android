package com.dinesh.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
public class Login extends AppCompatActivity {
    EditText username,password;
    Button login,register;

    Boolean savelogin;

    String DD3="Username";
    String DD4="Password";
    String s1,s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        username = (EditText) findViewById(R.id.etusername);
        password = (EditText) findViewById(R.id.etpassword);
        login = (Button) findViewById(R.id.btnlogin);
        register = (Button) findViewById(R.id.btnregister);

        s1 = MainActivity.sp.getString(DD3, null);
        s2 = MainActivity.sp.getString(DD4, null);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it2 = new Intent(Login.this, Register.class);
                startActivity(it2);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                if (user.equals(s1) && pass.equals(s2)) {


                    MainActivity.editor.putString("logincheck", "true");
                    MainActivity.editor.commit();

                    Intent it2 = new Intent(Login.this, Display.class);
                    startActivity(it2);

                    Toast.makeText(getApplicationContext(), "Login successfull", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Enter valid username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }  @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent( Login.this,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }
}
