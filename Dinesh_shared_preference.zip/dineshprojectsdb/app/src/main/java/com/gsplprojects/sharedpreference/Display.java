package com.gsplprojects.sharedpreference;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Display extends AppCompatActivity implements View.OnClickListener {

    public static final String TABLENAME="Registeration";

    String getName, getEmail, getMobile;

    TextView profile,profile2;

    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_display);

        //using key we are Retrieving data on Textview box

        getName = MainActivity.sp.getString("Username", null);
       getEmail = MainActivity.sp.getString("Emailid", null);
       getMobile = MainActivity.sp.getString("Mobile", null);

        profile2=(TextView)findViewById(R.id.tvdisplay2);
        profile = (TextView) findViewById(R.id.tvdisplay);
        logout = (Button) findViewById(R.id.btnlg);
        logout.setOnClickListener(this);

        profile.setText( "Name : " + getName + "\n" + "\n"
                        + "Email : " + getEmail + "\n" + "\n"
                        + "Mobile : " + getMobile);

    }

    @Override
    public void onClick(View v) {

        /*. In order to delete the complete data using call editor.clear(); followed by editor.commit();
          you can edit your complete profile by doing registration once again,
          it will overwrite your previous data.
         */

        Toast.makeText(getApplicationContext(), "You have successfully logout", Toast.LENGTH_LONG).show();

       MainActivity.editor.remove("logincheck");

        MainActivity.editor.commit();

        Intent it = new Intent(getApplicationContext(), Login.class);

        startActivity(it);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent(Display.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }
}
