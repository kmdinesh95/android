package com.gsplprojects.sharedpreference;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;


public class Register extends AppCompatActivity {


    Button register;
    EditText username, emailid, password, retypepassword,mbl;

    String DD = "Username";
    String DD2 = "Password";
    public final Pattern EMAILPATTERN = Pattern.compile(
            "[a-zA-Z0-9+._%-+]{1,256}" +
                    "@" +
                    "[a-zA-Z0-9][a-zA-Z0-9-]{0,64}" +
                    "(" +
                    "." +
                    "[a-zA-Z0-9][a-zA-Z0-9-]{0,25}" +
                    ")+"
    );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //Object initilization
        register = (Button) findViewById(R.id.reg);
        username = (EditText) findViewById(R.id.user);
        emailid = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.pass);
        retypepassword = (EditText) findViewById(R.id.repass);
        mbl=(EditText)findViewById(R.id.mbl);
        //Button Action
    register.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String user = username.getText().toString();
            String email = emailid.getText().toString();
            String pass = password.getText().toString();
            String retypepass = retypepassword.getText().toString();
            String mblno=mbl.getText().toString();

            int mob=Integer.parseInt(mblno);



                if (user.equalsIgnoreCase("") || pass.equalsIgnoreCase("") || retypepass.equalsIgnoreCase("")) {

                Toast.makeText(getApplicationContext(), "Please Fill Something", Toast.LENGTH_SHORT).show();

            } else if (!pass.equals(retypepass)) {

                Toast.makeText(getApplicationContext(), " password does not match", Toast.LENGTH_SHORT).show();

            } else if (!checkEmail(email)) {

                Toast.makeText(getApplicationContext(), "please check your mail id", Toast.LENGTH_SHORT).show();

            } else if (!mblno.equals(mblno)) {
                Toast.makeText(getApplicationContext(), "please Enter 10digit Number", Toast.LENGTH_SHORT).show();

            } else {
                //Shared preference
                MainActivity.editor.putString(DD, user);
                MainActivity.editor.putString("Emailid", email);
                MainActivity.editor.putString(DD2, pass);
                MainActivity.editor.putString("retypepassword", retypepass);
                MainActivity.editor.putString("Mobile",mblno);
                MainActivity.editor.commit();



                Intent it3 = new Intent(Register.this, Login.class);
                startActivity(it3);
               Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT).show();


            }
        }
    }
    );
    }





    private boolean checkEmail(String emailid) {
        return EMAILPATTERN.matcher(emailid).matches();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent(Register.this,Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }
}


