package com.dd.list_sqlite_volley;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ThemedSpinnerAdapter;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.dd.list_sqlite_volley.Sqlite.Helper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Mypojo> mypojos = new ArrayList<>();
    private ListView listView;
    ListAdapter listAdapter;
    Helper helper;

    ArrayList<String> name=new ArrayList<String>();
    ArrayList<String> area=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        listView=(ListView)findViewById(R.id.list);

        helper=new Helper(this);
        volley();
        loaddatasqlite();
    }




    public void volley(){



        final ProgressBar progressBar = (ProgressBar)findViewById(R.id.progress);

        progressBar.setVisibility(View.VISIBLE);



        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://legalnote.org//hotelrsbhavaan/indiangravy.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressBar.setVisibility(View.INVISIBLE);
                        // Toast.makeText(getApplication(),""+response,Toast.LENGTH_SHORT).show();
                        try {


                            //converting the string to json array object
                            JSONObject jsonObject=new JSONObject(response);



                            //JSONArray array = new JSONArray(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("result");




                            //traversing through all the object
                            for (int i = 0; i < jsonArray.length(); i++) {

                                //getting product object from json array
                                JSONObject product = jsonArray.getJSONObject(i);

                                helper.insert(
                                        product.getString("title"),
                                        product.getString("description")
                                );

                            }




                            loaddatasqlite();

                            Toast.makeText(getApplicationContext(),""+helper.numberOfRows(),Toast.LENGTH_SHORT).show();


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);
    }


    private void loaddatasqlite() {

        Cursor cursor=helper.display();
        if (cursor.moveToFirst()) {
            do {

                name.add(cursor.getString(1));
                area.add(cursor.getString(2));
            } while (cursor.moveToNext());
        }
        listAdapter=new com.dd.list_sqlite_volley.ListAdapter(this,name,area);
        listView.setAdapter(listAdapter);
    }


}
