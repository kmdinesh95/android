package com.dd.list_sqlite_volley.Sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dd on 22/3/18.
 */

public class Helper2 extends SQLiteOpenHelper {


    public Helper2(Context context) {
        super(context,"DB2.db",null,1);
    }




    @Override
    public void onCreate(SQLiteDatabase sqlite_db) {
   sqlite_db.execSQL("create table datas2"+"(id integer primary key AUTOINCREMENT, name text,area text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqlite_db, int i, int i1) {
        sqlite_db.execSQL("Drop table if exists datas2");
        onCreate(sqlite_db);
    }
    public  void insert(String name,String area){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("area",area);
        db.insert("datas2",null,contentValues);

    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, "datas2");
        return numRows;
    }


    public Cursor display(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;
        cursor=db.rawQuery(("SELECT * FROM datas2"), null);
        return cursor;
    }
}
