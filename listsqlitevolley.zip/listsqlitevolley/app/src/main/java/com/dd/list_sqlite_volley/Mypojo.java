package com.dd.list_sqlite_volley;

/**
 * Created by dd on 22/3/18.
 */

public class Mypojo {

    private String name, area;


    public Mypojo(String name, String area){

        this.name=name;
        this.area=area;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}


